<?php
  include 'server.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="rann,neeti,gmaes,sports,2019,2k19,gold,grab,the,iit,mandi,fest,latest,trending">
    <meta name="author" content="Dipanshu Verma and Naman Tayal">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>Rann Neeti 2019</title>

    <!-- Favicon -->
    <link rel="icon" href="./img/bg-img/logo .png">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Header Area Start -->
    <header class="header-area">
        <div class="classy-nav-container breakpoint-off">
            <div class="container">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="conferNav">

                    <!-- Logo -->
                    <a class="nav-brand" href="./index.html" style="max-width: 10%"><img src="./img/core-img/logo.png"></a>
                    <a class="nav-brand" href="http://iitmandi.ac.in/" style="max-width: 10%"><img src="./img/bg-img/iitmandi_logo.png"></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">
                        <!-- Menu Close Button -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>
                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul id="nav">
                                <li class="active"><a href="index.html">Home</a></li>
                                <li><a href="#">Pages</a>
                                    <ul class="dropdown">
                                        <li><a href="index.html">- Home</a></li>
                                        <li><a href="about.html">- About Us</a></li>
                                        <li><a href="speakers.html">- Team</a></li>
                                        <li><a href="schedule.html">- Schedule/Rules</a></li>
                                        <li><a href="register.php">- Register</a></li>
                                        <li><a href="contact.html">- Contact</a></li>
                                    </ul>
                                </li>
                                <li><a href="speakers.html">Team</a></li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>

                            <!-- Get Tickets Button -->
                            <a href="register.php" class="btn confer-btn mt-3 mt-lg-0 ml-3 ml-lg-5">Register <i class="zmdi zmdi-long-arrow-right"></i></a>
                        </div>
                        <!-- Nav End -->
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcrumb Area Start -->
    <section class="breadcrumb-area bg-img bg-gradient-overlay jarallax" style="background-image: url(img/bg-img/37.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2 class="page-title">Register</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Register</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Breadcrumb Area End -->

    <!-- Contact Us Area Start -->
    <section class="contact--us-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <!-- Contact Us Thumb -->
                <div class="col-12 col-lg-6">
                    <div class="contact-us-thumb mb-100">
                        <img src="img/bg-img/44.jpg" alt="">
                    </div>
                </div>

                <!-- Contact Form -->
                <div class="col-12 col-lg-6">
                    <div class="contact_from_area mb-100 clearfix">
                        <!-- Contact Heading -->
                        <div class="contact-heading">
                            <h4>Book Your Accomodation</h4>
                            <p>Register only once for one college. You will have to pay required fees after Registration</p>
                        </div>
                        <div class="contact_form">
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                <div class="contact_input_area">
                                    <div class="row">
                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control mb-30" name="name" id="name" placeholder="Leader Name" required>
                                            </div>
                                        </div>
                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control mb-30" name="college" id="name-2" placeholder="College Name" required>
                                            </div>
                                        </div>
                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="email" class="form-control mb-30" name="email" id="email" placeholder="E-mail" required>
                                            </div>
                                        </div>
                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="number" class="form-control mb-30" name="contact" id="subject" placeholder="Contact Number">
                                            </div>
                                        </div>
                                        <!-- Form Group -->
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="number" class="form-control mb-30" name="people" id="subject" placeholder="Number of Participants">
                                            </div>
                                        </div>

                                        <!-- checkbox -->
                                        <div class="col-12">
                                            <h4>Events</h4>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Table-Tennis(Boys)" value="Table-Tennis (Boys)">Table-Tennis (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Table-Tennis(Girls)" value="Table-Tennis (Girls)">Table-Tennis (Girls)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Badminton(Boys)" value="Badminton (Boys)">Badminton (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Badminton(Girls)" value="Badminton (Girls)">Badminton (Girls)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Basketball(Boys)" value="Basketball (Boys)">Basketball (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Basketball(Girls)" value="Basketball (Girls)">Basketball (Girls)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Football(Boys)" value="Football (Boys)">Football (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Cricket(Boys)" value="Cricket (Boys)">Cricket (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Volleyball(Boys)" value="Volleyball (Boys)">Volleyball (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Volleyball(Girls)" value="Volleyball (Girls)">Volleyball (Girls)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Hockey(Boys)" value="Hockey (Boys)">Hockey (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Athletics(Boys)" value="Athletics (Boys)">Athletics (Boys)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Athletics(Girls)" value="Athletics (Girls)">Athletics (Girls)</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Lawn-Tennis" value="Lawn-Tennis">Lawn-Tennis</label>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                          <label><input class="mybox" type="checkbox" name="Chess" value="Chess">Chess</label>
                                        </div>
                                        <br>
                                        <!-- Button -->
                                        <div class="col-12">
                                            <button type="submit" class="btn confer-btn" name="submit">Book Now<i class="zmdi zmdi-long-arrow-right"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Us Area End -->

    <!-- Map Area -->
    <div class="map-area">
        <iframe src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJgf2xVGDjBDkROfPJ3pBKF8M&key=AIzaSyDt0vmrDjhqkRsggokYMg9UbtDt4-Cnljw" allowfullscreen></iframe>
    </div>

    <!-- Contact Info Area -->
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="contact--info-area bg-boxshadow">
                    <div class="row">
                        <!-- Single Contact Info -->
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="single-contact--info text-center">
                                <!-- Contact Info Icon -->
                                <div class="contact--info-icon">
                                    <img src="img/core-img/icon-5.png" alt="">
                                </div>
                                <h5>IIT Mandi, HIMACHAL PRADESH</h5>
                            </div>
                        </div>

                        <!-- Single Contact Info -->
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="single-contact--info text-center">
                                <!-- Contact Info Icon -->
                                <div class="contact--info-icon">
                                    <img src="img/core-img/icon-6.png" alt="">
                                </div>
                                <h5>99172 48334</h5>
                            </div>
                        </div>

                        <!-- Single Contact Info -->
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="single-contact--info text-center">
                                <!-- Contact Info Icon -->
                                <div class="contact--info-icon">
                                    <img src="img/core-img/icon-7.png" alt="">
                                </div>
                                <h5>public_relations@rann-neeti.co</h5>
                            </div>
                        </div>

                        <!-- Single Contact Info -->
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="single-contact--info text-center">
                                <!-- Contact Info Icon -->
                                <div class="contact--info-icon">
                                    <img src="img/core-img/icon-8.png" alt="">
                                </div>
                                <h5>rann-neeti.co</h5>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Area Start -->
    <footer class="footer-area bg-img bg-overlay-2 section-padding-100-0">
        <!-- Main Footer Area -->
        <div class="main-footer-area" >
            <div class="container" >
                <div class="row">
                    <!-- Single Footer Widget Area -->
                    <div class="col-sm-4 ">
                            <div class="single-footer-widget mb-60 wow fadeInUp" data-wow-delay="300ms">
                                <!-- Widget Title -->
                                <h5 class="widget-title">Contact</h5>
    
                                <!-- Contact Area -->
                                <div class="footer-contact-info">
                                    <p><i class="zmdi zmdi-map"></i> IIT MANDI, HIMACHAL PRADESH</p>
                                    <p><i class="zmdi zmdi-phone"></i> Ram Agarwal -  99172 48334</p>
                                    <p><i class="zmdi zmdi-email"></i> public_relations@rann-neeti.co</p>  
                                </div>
                            </div>
                        </div>


                    <!-- Single Footer Widget Area -->
                    <div class="col-sm-4 ">
                        <div class="single-footer-widget mb-60 wow fadeInUp" data-wow-delay="300ms">
                            <!-- Footer Logo -->
                            <a href="index.html" class="footer-logo" style="text-align: center"><img src="img/core-img/logo.png" style="width: 50%"></a>
                            <p align='center'>Rann Neeti 2019 <br> All rights reserved</p>

                            <!-- Social Info -->
                            <div class="social-info" style="text-align: center">
                                <a href="https://www.facebook.com/Rannneetivqv/" target="_blank"><i class="zmdi zmdi-facebook"></i></a>
                                <a href="https://www.instagram.com/rann_neeti.iitmandi/?hl=en" target="_blank"><i class="zmdi zmdi-instagram"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Single Footer Widget Area -->
                    

                    <!-- Single Footer Widget Area -->
                    <div class="col-sm-4 ">
                            <div class="single-footer-widget mb-60 wow fadeInUp" data-wow-delay="300ms">
                                <!-- Widget Title -->
                                <h5 class="widget-title">Gallery</h5>
    
                                <!-- Footer Gallery -->
                                <div class="footer-gallery">
                                    <div class="row">
                                        <div class="col-4">
                                            <a href="img/bg-img/baddy2.jpg" class="single-gallery-item"><img src="img/bg-img/baddy2.jpg" alt=""></a>
                                        </div>
                                        <div class="col-4">
                                            <a href="img/bg-img/baddy-min.jpg" class="single-gallery-item"><img src="img/bg-img/baddy-min.jpg" alt=""></a>
                                        </div>
                                        <div class="col-4">
                                            <a href="img/bg-img/volly-min.jpg" class="single-gallery-item"><img src="img/bg-img/volly-min.jpg" alt=""></a>
                                        </div>
                                        <div class="col-4">
                                            <a href="img/bg-img/cricket-min.jpg" class="single-gallery-item"><img src="img/bg-img/cricket-min.jpg" alt=""></a>
                                        </div>
                                        <div class="col-4">
                                            <a href="img/bg-img/tt-min.jpg" class="single-gallery-item"><img src="img/bg-img/tt-min.jpg" alt=""></a>
                                        </div>
                                        <div class="col-4">
                                            <a href="img/bg-img/hockey-min.jpg" class="single-gallery-item"><img src="img/bg-img/hockey-min.jpg" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>

        <!-- Copywrite Area -->
        <div class="container">
            <div class="copywrite-content">
                <div class="row">
                    <!-- Copywrite Text -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite-text">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                    <!-- Footer Menu -->
                    <div class="col-12 col-md-6">
                        <div class="footer-menu">
                            <ul class="nav">
                                <li><a href="#"><i class="zmdi zmdi-circle"></i> Terms of Service</a></li>
                                <li><a href="#"><i class="zmdi zmdi-circle"></i> Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->

    <!-- **** All JS Files ***** -->
    <!-- jQuery 2.2.4 -->
    <script src="js/jquery.min.js"></script>
    <!-- Popper -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All Plugins -->
    <script src="js/confer.bundle.js"></script>
    <!-- Active -->
    <script src="js/default-assets/active.js"></script>

</body>

</html>
